#!/bin/sh
#text=`echo \'$1\' | sed -f repl.sed`
#echo $1 | sed -f repl.sed
echo $1 | sed -f repl.sed | pdsend 3005
