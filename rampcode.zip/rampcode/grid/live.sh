#!/bin/bash


declare -a BYTE

LOGFILE="logs/${EPOCHSECONDS}.log"
date > ${LOGFILE}

BANKS0="${1}banks.0"
BANKS3="${1}banks.3"

echo "Folder ${1}"

Movecursor(){
	printf "\e[$(( ${2}+1 ));$(( ${1}+1 ))H"
}

Scan(){
	FROM=${1}
	echo "Scan expression ${@:2} for parameters" >>${LOGFILE}

	for ((i=2;i<=$#;i++)); do
		if [ "${!i:0:1}" == "p" ]; then
			echo "Assign parameter ${!i:1} to byte ${FROM}" >>${LOGFILE}
			BYTE[${FROM}]="${!i:1}"
			((FROM++))
		fi
	done
}

Replace(){	
	FROM=${1}
	echo "Replace expression ${@:2} parameters with values starting from byte ${FROM}" >>${LOGFILE}

	REPLACED=""
	
	if [[ $(echo $@ | grep -o v1) == "" ]]; then
		echo "Assume RPN notation" >>${LOGFILE}
		for ((i=2;i<=$#;i++)); do
			if [ "${!i:0:1}" == "p" ]; then
				echo "Replace ${!i:1} for byte ${FROM} (${BYTE[${FROM}]})" >>${LOGFILE}
				REPLACED="${REPLACED} ${BYTE[${FROM}]}"
				((FROM++))
			else
				REPLACED="${REPLACED} ${!i}"
			fi
		done

		echo "Convert ${REPLACED} to PD infix notation" >>${LOGFILE}
		TOPD=$(./ptoi.sh ${REPLACED})
		
	else
		echo "Assume PD infix notation" >>${LOGFILE}
		for ((i=2;i<=$#;i++)); do
			if [ "${!i:0:1}" == "p" ]; then
				echo "Replace ${!i:1} for byte ${FROM} (value: ${BYTE[${FROM}]})" >>${LOGFILE}
	       			REPLACED="${REPLACED}${BYTE[${FROM}]}"
				((FROM++))
			else
				REPLACED="${REPLACED}${!i}"
			fi
		done
		
		TOPD="${REPLACED}"
	fi
	
	echo "Send ${TOPD};" >>${LOGFILE}

	case ${1} in
		1 ) echo "$TOPD;" | pdsend 3031 ;;
		4 ) echo "$TOPD;" | pdsend 3030 ;;
	esac
}

Update(){
	BANKA=$(eval sed '$((BYTE[0]+1))!d' ${BANKS0})
	BANKB=$(eval sed '$((BYTE[3]+1))!d' ${BANKS3})

	case ${cury} in 
		0 )	Scan 1 ${BANKA}
			Replace 1 ${BANKA}
			;;
		1|2 )	Replace 1 ${BANKA}
			;;
		3 )	Scan 4 ${BANKB}
			Replace 4 ${BANKB}
			;;
		* ) 	Replace 4 ${BANKB}
			;;
	esac
	
}

Editgrid(){
	while true
	do
		Movecursor 24 0; echo -ne "\033[0;31m"; echo "obase=16;${BYTE[0]}" | bc
		Movecursor 24 3; echo "${BYTE[3]}  " #echo "obase=16;${BYTE[3]}" | bc

		for i in {0..64}
		do
			Movecursor $(( (i&7)*2 )) $(( i>>3&7 ))
			echo -ne "\033[0;$(( 30|BYTE[i>>3&7]>>(i&7)&1 ))m*"
#			[ $((i&7)) -eq 7 ] && H=$(echo "obase=16;$((BYTE[i>>3&7]))" | bc) && echo -n " $H "
		done

		Movecursor $(( curx*2 )) ${cury}
		read -s -n1
	
		case ${REPLY} in
			k ) (( cury-- )) ;;

			h ) (( curx-- )) ;;

			j ) (( cury++ )) ;;

			l ) (( curx++ )) ;;

			1|2|3|4|5|6|7|8 ) cury=$((REPLY-1)) ;;
	
			f ) BYTE[${cury}]=$(( BYTE[cury] ^ 1<<curx )) 
				Update
				;;
	
			s|- ) BYTE[${cury}]=$(( BYTE[cury]-1 &255 )) 
				Update
				;;

			a|+ ) BYTE[${cury}]=$(( BYTE[cury]+1 &255 )) 
				Update
				;;
			
			0 ) read -s -n1 N
				BYTE[${cury}]=$((N&255))
				Update
				;;
			r ) BYTE[${cury}]=$((RANDOM&15)) 
				Update
				;;
			u ) Update ;;
			L ) clear ;;
		esac
		
		curx=$(( curx &7 ))
		cury=$(( cury &7 ))

	done


}

cury=0
curx=0
grid[0]=0
grid[3]=0

clear

Editgrid

