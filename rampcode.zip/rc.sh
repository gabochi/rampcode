#!/bin/bash

rcdir=$PWD
logfile="${rcdir}/logs/$(date +%Y%m%d%H%M)"

source ${rcdir}/scripts/functions.sh

echo "rampcode"

case ${1} in
	"-e" )
	eval "$2"
	;;
	"-r" | "" )
	[ "${1}"=="-r" ] && history -r "${2}"
	while true; do
		read -e -p "r$ " command
		eval "${command}"
		history -s "${command}"
		history -w "${logfile}"	
	done
	;;
	* )
	echo "args: none, -e expression, -r logfile"
	;;
esac
