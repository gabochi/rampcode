#!/bin/bash

# SCALES

aeo="0x23578ac"
art="0x24578bc"
dor="0x23579ac"
fri="0x13578ac"
har="0x23578bc"
jon="0x24579bc"
lid="0x24679bc"
loc="0x13568ac"
mix="0x24579ac"
pma="0x02479ce"
pmi="0x0357acf"

# COMMUNICATION

# send expressions

ch(){
	expression=${2}
	echo "${1} ${expression};" | sed -f ${rcdir}/scripts/replace.sed
	echo "${1} ${expression};" | sed -f ${rcdir}/scripts/replace.sed | pdsend 8080
}

# change cps

hz(){
	echo "${1};" | pdsend 8081
}

# SEQUENCERS

# binary

bs(){
	echo "((${1})>>(${2})&1)"
}

# euclidean

eu(){
	echo "((t+((1<<(${1}))*(${4:-0}))>>(${1}))%(${2})*(${3})%(${2})<(${3}))"
}

# hex

hs(){
	echo "((${1})>>(${2})*4&15)"
}

# MELODY

# tet-12

tt(){
	echo "(t*(pow(2,(${1})/12.0)))"
}

# vibrato

vi(){
	echo "(sin(t/(${1}))*(${2}))"
}

# AMPLITUDE

# envelope

en(){
	echo "(((${1})&255)*pow((t*(${4:--1})>>(${2})&255)/255,${3}))"
	#	old: if((t&255)<32,(t&255)/32,(256-(t&255))/256)
}

# amplitude modulation

am(){
	echo "((sin(t/(${1}))*0.5+0.5)*(${2:-1})+(${3:-0}))"
}

# t

t(){
	echo "${2}" | sed "s/t/\(${1}\)/g"
}

# "PRESETS"

# sine

si(){
	echo "(sin((${1})*3.14/64)*127+128)"
}

# fm

fm(){
	echo "(sin((${1})*3.14/64+sin((${1})*(${2})*3.14/64)*(${3}))*127+128)"
}

# perc1

tk(){
	echo "[tM[-tr[${1}]A[2l[${2}]]-1]]"
}

# perc2

sk(){
	echo "(sin((1<<(${1}))/(t&(1<<(${1}))-1)*(${2}))*127+128)"
}

# RANDOM

ra(){
	echo "(sin((t>>(${1}))*sin(t>>(${1}))+(${2:-$((RANDOM&255))}))*0.5+0.5)"
}

# EXTRA

# testing expressions

test(){
	for i in {0..63}; do
		((o=$((${1}))))
		printf "${o}; "
		((t++))
	done

	printf "\n"
}
